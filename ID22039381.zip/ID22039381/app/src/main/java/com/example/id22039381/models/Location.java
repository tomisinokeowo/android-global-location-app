package com.example.id22039381.models;

public class Location {

    //location data fields - Variables are 1st being declared.
    private String name;
    private String country;
    private String gpsCoordinates;
    private String dateVisited;
    private int rating;

    //this is our constructor - Initialising the above variables.
    public Location(String name, String country, String gpsCoordinates, String dateVisited, int rating){
        this.name = name;
        this.country = country;
        this.gpsCoordinates = gpsCoordinates;
        this.dateVisited = dateVisited;
        this.rating = rating;
    }




    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getGpsCoordinates() {
        return gpsCoordinates;
    }

    public void setGpsCoordinates(String gpsCoordinates) {
        this.gpsCoordinates = gpsCoordinates;
    }

    public String getDateVisited() {
        return dateVisited;
    }

    public void setDateVisited(String dateVisited) {
        this.dateVisited = dateVisited;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}