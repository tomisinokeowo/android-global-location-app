package com.example.id22039381.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.id22039381.R;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Dynamically set the title for this activity
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Location App");
        }


        Button btnAddLocation = findViewById(R.id.btn_add_location);
        Button btnViewLocations = findViewById(R.id.btn_view_locations);

        btnAddLocation.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddLocationActivity.class);
            startActivity(intent);
        });

        btnViewLocations.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ViewLocationsActivity.class);
            startActivity(intent);
        });

    }
}