package com.example.id22039381.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.id22039381.R;
import com.example.id22039381.database.DatabaseHelper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

public class AddLocationActivity extends AppCompatActivity {

    // Constant for location permission request code
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    // FusedLocationProviderClient to get the device's location
    private FusedLocationProviderClient fusedLocationProviderClient;

    // EditText to display the GPS coordinates
    private EditText etGps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_location); // Set the layout for this activity

        // Initialize input fields (EditText and Buttons)
        EditText etName = findViewById(R.id.et_name);
        etGps = findViewById(R.id.et_gps); // EditText for GPS coordinates
        EditText etCountry = findViewById(R.id.et_country);
        EditText etDate = findViewById(R.id.et_date);
        EditText etRating = findViewById(R.id.et_rating);
        Button btnFetchGps = findViewById(R.id.btn_get_current_gps_location); // Button to fetch current GPS
        Button btnSubmit = findViewById(R.id.btn_submit); // Button to submit location details

        // Initialize FusedLocationProviderClient to access device location services
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        // Set up click listener for the "Get Current GPS" button
        btnFetchGps.setOnClickListener(v -> {
            // Check if the app has permission to access location
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // If permission is not granted, request it
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            } else {
                // If permission is granted, fetch the current location
                fetchCurrentLocation();
            }
        });

        // Handle form submission when the "Submit" button is clicked
        btnSubmit.setOnClickListener(v -> {
            // Retrieve user inputs from the form fields
            String name = etName.getText().toString();
            String country = etCountry.getText().toString();
            String gps = etGps.getText().toString();
            String date = etDate.getText().toString();
            String ratingText = etRating.getText().toString();

            // Validate that all required fields are filled out
            if (name.isEmpty() || country.isEmpty() || gps.isEmpty() || date.isEmpty() || ratingText.isEmpty()) {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
                return; // Exit if any field is empty
            }

            // Validate that the rating is a valid number and within range
            int rating;
            try {
                rating = Integer.parseInt(ratingText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Rating must be a number!", Toast.LENGTH_SHORT).show();
                return; // Exit if the rating is not a valid number
            }

            // Check if the rating is between 1 and 10
            if (rating < 1 || rating > 10) {
                Toast.makeText(this, "Rating must be between 1 and 10!", Toast.LENGTH_SHORT).show();
                return; // Exit if the rating is out of range
            }

            // Add the location to the database
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            long id = dbHelper.addLocation(name, country, gps, date, rating);

            // Display success or failure message
            if (id > 0) {
                Toast.makeText(this, "Location added!", Toast.LENGTH_SHORT).show();
                finish(); // Close the activity if location is added successfully
            } else {
                Toast.makeText(this, "Failed to add location!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Handle the result of the permission request
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            // If permission is granted, fetch the current location
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchCurrentLocation();
            } else {
                // If permission is denied, show a message to the user
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void fetchCurrentLocation() {
        // Check if location permission is granted before proceeding
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission not granted!", Toast.LENGTH_SHORT).show();
            return; // Exit if permission is not granted
        }

        // Create a location request with high accuracy
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY); // High accuracy for location
        locationRequest.setInterval(10000);  // Request location updates every 10 seconds
        locationRequest.setFastestInterval(5000);  // Request updates every 5 seconds at the fastest

        // Request location updates using FusedLocationProviderClient
        fusedLocationProviderClient.requestLocationUpdates(locationRequest, new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                // Check if location result is null
                if (locationResult == null) {
                    Toast.makeText(AddLocationActivity.this, "Location not found", Toast.LENGTH_SHORT).show();
                    return; // Exit if location is not found
                }
                // Loop through the locations and update the EditText with current location
                for (Location location : locationResult.getLocations()) {
                    etGps.setText(location.getLatitude() + ", " + location.getLongitude());
                }
            }
        }, Looper.getMainLooper()); // Use the main thread's Looper for UI updates
    }
}
