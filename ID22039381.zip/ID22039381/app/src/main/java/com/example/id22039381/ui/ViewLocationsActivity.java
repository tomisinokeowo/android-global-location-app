package com.example.id22039381.ui;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.id22039381.R;
import com.example.id22039381.database.DatabaseHelper;

public class ViewLocationsActivity extends AppCompatActivity {

    private LocationAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_locations);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Dynamically set the title for this activity
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("View Locations");
        }
        
        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new LocationAdapter(this);
        recyclerView.setAdapter(adapter);

        // Load data from database
        loadLocations(null);

        // Handle sorting
        Spinner spinnerSort = findViewById(R.id.spinner_sort);
        spinnerSort.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                String sortBy = parent.getItemAtPosition(position).toString();
                loadLocations(sortBy);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
    }

    private void loadLocations(String sortBy) {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        Cursor cursor;
        if ("Name".equals(sortBy)) {
            cursor = dbHelper.getAllLocationsSortedBy("name");
        } else if ("Rating".equals(sortBy)) {
            cursor = dbHelper.getAllLocationsSortedBy("rating");
        } else if ("Date".equals(sortBy)) {
            cursor = dbHelper.getAllLocationsSortedBy("date_visited");
        } else if ("Distance from Current Location".equals(sortBy)) {
                cursor = dbHelper.getAllLocationsSortedBy("distance");
        } else {
            cursor = dbHelper.getAllLocations();
        }

        adapter.setCursor(cursor);
    }
}