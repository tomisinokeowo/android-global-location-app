package com.example.id22039381.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database configuration
    private static final String DATABASE_NAME = "locations.db";
    private static final int DATABASE_VERSION = 1;

    // Table and columns
    private static final String TABLE_LOCATIONS = "locations";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_COUNTRY = "country";
    private static final String COLUMN_GPS = "gps_coordinates";
    private static final String COLUMN_DATE = "date_visited";
    private static final String COLUMN_RATING = "rating";

    // SQL to create the table
    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_LOCATIONS + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT, " +
            COLUMN_COUNTRY + " TEXT, " +
            COLUMN_GPS + " TEXT, " +
            COLUMN_DATE + " TEXT, " +
            COLUMN_RATING + " INTEGER)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * creates table
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);

    }

    /**
     *
     * @param db         The database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOCATIONS);
        onCreate(db);
    }



    public long addLocation(String name, String country, String gps, String date, int rating) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_COUNTRY, country);
        values.put(COLUMN_GPS, gps);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_RATING, rating);
        return db.insert(TABLE_LOCATIONS, null, values);
    }


    public Cursor getAllLocations() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_LOCATIONS, null, null, null, null, null, COLUMN_NAME + " ASC");
    }

    public int deleteLocation(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_LOCATIONS, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }
    // Get All Locations Sorted by Column
    public Cursor getAllLocationsSortedBy(String column) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Validate column name to prevent SQL injection
        if (!column.equals(COLUMN_NAME) && !column.equals(COLUMN_RATING) && !column.equals(COLUMN_DATE)) {
            throw new IllegalArgumentException("Invalid column name for sorting: " + column);
        }

        // Query to fetch all locations sorted by the given column
        return db.query(TABLE_LOCATIONS, null, null, null, null, null, column + " ASC");
    }
}
