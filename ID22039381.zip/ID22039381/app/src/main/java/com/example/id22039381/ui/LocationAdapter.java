package com.example.id22039381.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.id22039381.R;
import com.example.id22039381.database.DatabaseHelper;

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {
    private Cursor cursor;
    private final Context context;

    public LocationAdapter(Context context) {
        this.context = context;
    }

    // Method to set the cursor and notify the adapter
    public void setCursor(Cursor cursor) {
        this.cursor = cursor;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public LocationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_location, parent, false);
        return new LocationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LocationViewHolder holder, int position) {
        // Ensure the cursor is not null before accessing it
        if (cursor != null && cursor.moveToPosition(position)) {
            @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
            @SuppressLint("Range") String country = cursor.getString(cursor.getColumnIndex("country"));
            @SuppressLint("Range") String gps = cursor.getString(cursor.getColumnIndex("gps_coordinates"));
            @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex("date_visited"));
            @SuppressLint("Range") int rating = cursor.getInt(cursor.getColumnIndex("rating"));
            @SuppressLint("Range") long id = cursor.getLong(cursor.getColumnIndex("id"));

            // Set the data for the views
            holder.tvName.setText(name);
            holder.tvCountry.setText(country);
            holder.tvDetails.setText("GPS: " + gps + ", Date: " + date + ", Rating: " + rating);

            // Handle delete button click
            holder.btnDelete.setOnClickListener(v -> {
                DatabaseHelper dbHelper = new DatabaseHelper(context);
                // Delete the location using the ID
                int rowsDeleted = dbHelper.deleteLocation(id);
                if (rowsDeleted > 0) {
                    // Show success message
                    Toast.makeText(context, "Location deleted!", Toast.LENGTH_SHORT).show();
                    // After deletion, refresh the cursor
                    Cursor updatedCursor = dbHelper.getAllLocations();
                    setCursor(updatedCursor);  // Refresh data in RecyclerView
                } else {
                    // Show error message if deletion failed
                    Toast.makeText(context, "Failed to delete location.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        // Return the number of items in the cursor
        return (cursor == null) ? 0 : cursor.getCount();
    }

    static class LocationViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCountry, tvDetails;
        ImageButton btnDelete;

        public LocationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_name);
            tvCountry = itemView.findViewById(R.id.tv_country);
            tvDetails = itemView.findViewById(R.id.tv_details);
            btnDelete = itemView.findViewById(R.id.btn_delete);
        }
    }
}
